-- MySQL dump 10.13  Distrib 8.0.28, for Linux (x86_64)
--
-- Host: localhost    Database: delta
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BA388B74584665A` (`product_id`),
  CONSTRAINT `FK_BA388B74584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_64C19C1727ACA70` (`parent_id`),
  CONSTRAINT `FK_64C19C1727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,NULL,'TV',0),(2,NULL,'Smartphones',8),(3,1,'Old TV',1),(4,1,'New TV',8),(5,2,'Iphone',8),(6,2,'Meizu',8),(7,3,'Old black TV',2),(8,3,'Old red TV',3),(9,4,'New red TV',5);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `text` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9474526C4584665A` (`product_id`),
  CONSTRAINT `FK_9474526C4584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,6,'Alex','2022-03-18 17:04:18','Good',4),(2,5,'Alex','2022-03-18 17:04:45','Not bad',3),(3,4,'Alex','2022-03-18 17:05:11','!!!!',2);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fos_user__group`
--

DROP TABLE IF EXISTS `fos_user__group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fos_user__group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CDA27E965E237E06` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fos_user__group`
--

LOCK TABLES `fos_user__group` WRITE;
/*!40000 ALTER TABLE `fos_user__group` DISABLE KEYS */;
/*!40000 ALTER TABLE `fos_user__group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fos_user__user`
--

DROP TABLE IF EXISTS `fos_user__user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fos_user__user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `firstname` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `biography` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_uid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook_data` json DEFAULT NULL,
  `twitter_uid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_data` json DEFAULT NULL,
  `gplus_uid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gplus_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gplus_data` json DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_step_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E54BFDA992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_E54BFDA9A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_E54BFDA9C05FB297` (`confirmation_token`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fos_user__user`
--

LOCK TABLES `fos_user__user` WRITE;
/*!40000 ALTER TABLE `fos_user__user` DISABLE KEYS */;
INSERT INTO `fos_user__user` VALUES (1,'admin','admin','admin@admin.ru','admin@admin.ru',1,'bqbwGUO2hGf69DwjZ8DlahHVn/M6wpbhsRb4JMuHTmQ','vD7NiVu0BnebYwgOj2MJocdhKxYyTqvMmX0S99bVjfysAF6HHakCvhkpXdDa/ETv79E4bLbjuRQjomtMINMDtw==','2022-03-18 16:44:24',NULL,NULL,'a:1:{i:0;s:16:\"ROLE_SUPER_ADMIN\";}','2022-03-18 16:44:07','2022-03-18 16:44:24',NULL,NULL,NULL,NULL,NULL,'u',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `fos_user__user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fos_user_user_group`
--

DROP TABLE IF EXISTS `fos_user_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fos_user_user_group` (
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`),
  KEY `IDX_B3C77447A76ED395` (`user_id`),
  KEY `IDX_B3C77447FE54D947` (`group_id`),
  CONSTRAINT `FK_B3C77447A76ED395` FOREIGN KEY (`user_id`) REFERENCES `fos_user__user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_B3C77447FE54D947` FOREIGN KEY (`group_id`) REFERENCES `fos_user__group` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fos_user_user_group`
--

LOCK TABLES `fos_user_user_group` WRITE;
/*!40000 ALTER TABLE `fos_user_user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `fos_user_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media__gallery`
--

DROP TABLE IF EXISTS `media__gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media__gallery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_format` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media__gallery`
--

LOCK TABLES `media__gallery` WRITE;
/*!40000 ALTER TABLE `media__gallery` DISABLE KEYS */;
INSERT INTO `media__gallery` VALUES (1,'Meizu11','product','reference',0,'2022-03-18 16:49:26','2022-03-18 16:49:26'),(2,'Meizu22','product','reference',0,'2022-03-18 16:50:21','2022-03-18 16:50:21'),(3,'Iphone22','product','reference',0,'2022-03-18 16:51:36','2022-03-18 16:51:36'),(4,'OldRedTV1000','product','reference',0,'2022-03-18 16:53:35','2022-03-18 16:53:35'),(5,'Old red TV 1000','product','reference',0,'2022-03-18 17:01:14','2022-03-18 17:01:14'),(6,'New red tv 000','product','reference',0,'2022-03-18 17:02:08','2022-03-18 17:02:08');
/*!40000 ALTER TABLE `media__gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media__gallery_has_media`
--

DROP TABLE IF EXISTS `media__gallery_has_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media__gallery_has_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gallery_id` int DEFAULT NULL,
  `media_id` int DEFAULT NULL,
  `position` int NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_2BBF327D4E7AF8F` (`gallery_id`),
  KEY `IDX_2BBF327DEA9FDD75` (`media_id`),
  CONSTRAINT `FK_2BBF327D4E7AF8F` FOREIGN KEY (`gallery_id`) REFERENCES `media__gallery` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_2BBF327DEA9FDD75` FOREIGN KEY (`media_id`) REFERENCES `media__media` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media__gallery_has_media`
--

LOCK TABLES `media__gallery_has_media` WRITE;
/*!40000 ALTER TABLE `media__gallery_has_media` DISABLE KEYS */;
INSERT INTO `media__gallery_has_media` VALUES (1,1,2,1,0,'2022-03-18 16:49:26','2022-03-18 16:49:26'),(2,1,3,2,0,'2022-03-18 16:49:26','2022-03-18 16:49:26'),(3,2,5,1,0,'2022-03-18 16:50:21','2022-03-18 16:50:21'),(4,3,7,1,0,'2022-03-18 16:51:36','2022-03-18 16:51:36'),(5,4,9,1,0,'2022-03-18 16:53:35','2022-03-18 16:53:35'),(6,5,12,1,0,'2022-03-18 17:01:14','2022-03-18 17:01:14'),(7,6,14,1,0,'2022-03-18 17:03:46','2022-03-18 17:02:08');
/*!40000 ALTER TABLE `media__gallery_has_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media__media`
--

DROP TABLE IF EXISTS `media__media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media__media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL,
  `provider_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_status` int NOT NULL,
  `provider_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_metadata` json DEFAULT NULL,
  `width` int DEFAULT NULL,
  `height` int DEFAULT NULL,
  `length` decimal(10,0) DEFAULT NULL,
  `content_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_size` int DEFAULT NULL,
  `copyright` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `context` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cdn_is_flushable` tinyint(1) DEFAULT NULL,
  `cdn_flush_identifier` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cdn_flush_at` datetime DEFAULT NULL,
  `cdn_status` int DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media__media`
--

LOCK TABLES `media__media` WRITE;
/*!40000 ALTER TABLE `media__media` DISABLE KEYS */;
INSERT INTO `media__media` VALUES (1,'product04.png',NULL,0,'sonata.media.provider.image',1,'b9c73fdaf810bc47f2a1dcdc93901188801131db.png','{\"filename\": \"product04.png\"}',600,600,NULL,'image/png',197972,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 16:48:36','2022-03-18 16:48:36'),(2,'product04.png',NULL,0,'sonata.media.provider.image',1,'dbe0a43920a9fee36ffb34fbe3eed1855b627ce2.png','{\"filename\": \"product04.png\"}',600,600,NULL,'image/png',197972,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 16:48:46','2022-03-18 16:48:46'),(3,'product04.png',NULL,0,'sonata.media.provider.image',1,'07cc9894101ac8dee9a0578b9fc10734e2aeb231.png','{\"filename\": \"product04.png\"}',600,600,NULL,'image/png',197972,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 16:49:01','2022-03-18 16:49:01'),(4,'product07.png',NULL,0,'sonata.media.provider.image',1,'b6d3834c6bde2a1f7b33d5d74f8f1e8161e71ca7.png','{\"filename\": \"product07.png\"}',600,600,NULL,'image/png',174505,NULL,NULL,'product',0,NULL,NULL,NULL,'2022-03-18 16:49:26','2022-03-18 16:49:26'),(5,'product06.png',NULL,0,'sonata.media.provider.image',1,'fabba95185423fed49146a263548343ce8504ff3.png','{\"filename\": \"product06.png\"}',600,600,NULL,'image/png',222902,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 16:49:59','2022-03-18 16:49:59'),(6,'product07.png',NULL,0,'sonata.media.provider.image',1,'c14c426b77b070ec5e9144e50df6406160918732.png','{\"filename\": \"product07.png\"}',600,600,NULL,'image/png',174505,NULL,NULL,'product',0,NULL,NULL,NULL,'2022-03-18 16:50:21','2022-03-18 16:50:21'),(7,'product05.png',NULL,0,'sonata.media.provider.image',1,'21bfb90f20dfdef6cf0ff4552244268680f1edf6.png','{\"filename\": \"product05.png\"}',600,600,NULL,'image/png',124399,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 16:51:32','2022-03-18 16:51:32'),(8,'product07.png',NULL,0,'sonata.media.provider.image',1,'bef6fb2448dfceb1562a278861db865ba43c013c.png','{\"filename\": \"product07.png\"}',600,600,NULL,'image/png',174505,NULL,NULL,'product',0,NULL,NULL,NULL,'2022-03-18 16:51:36','2022-03-18 16:51:36'),(9,'product08.png',NULL,0,'sonata.media.provider.image',1,'645ec5b27e82ff3eaabd6ebe7b0a58702f67f6c0.png','{\"filename\": \"product08.png\"}',600,600,NULL,'image/png',227676,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 16:52:48','2022-03-18 16:52:48'),(10,'product08.png',NULL,0,'sonata.media.provider.image',1,'8bed6673fbb73d4333efa8b689efe739a56e4fc8.png','{\"filename\": \"product08.png\"}',600,600,NULL,'image/png',227676,NULL,NULL,'product',0,NULL,NULL,NULL,'2022-03-18 16:53:35','2022-03-18 16:53:35'),(11,'product05.png',NULL,0,'sonata.media.provider.image',1,'035d6f7facd061874a28ae4fa6e7decb599a3e11.png','{\"filename\": \"product05.png\"}',600,600,NULL,'image/png',124399,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 17:00:33','2022-03-18 17:00:33'),(12,'product08.png',NULL,0,'sonata.media.provider.image',1,'73e452e79def20e8e1b4ebcc12e8a3c5c0204d98.png','{\"filename\": \"product08.png\"}',600,600,NULL,'image/png',227676,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 17:01:08','2022-03-18 17:01:08'),(13,'product03.png',NULL,0,'sonata.media.provider.image',1,'738aa749d87a86774513a22315d8868bfc381173.png','{\"filename\": \"product03.png\"}',600,600,NULL,'image/png',234903,NULL,NULL,'product',0,NULL,NULL,NULL,'2022-03-18 17:01:14','2022-03-18 17:01:14'),(14,'product06.png',NULL,0,'sonata.media.provider.image',1,'f1031008ca39646b3becb27b08a73f628c14eb4a.png','{\"filename\": \"product06.png\"}',600,600,NULL,'image/png',222902,NULL,NULL,'default',0,NULL,NULL,NULL,'2022-03-18 17:01:59','2022-03-18 17:01:59'),(15,'product06.png',NULL,0,'sonata.media.provider.image',1,'e6f51214be478009d136e3f8c42af9cba164fdbc.png','{\"filename\": \"product06.png\"}',600,600,NULL,'image/png',222902,NULL,NULL,'product',0,NULL,NULL,NULL,'2022-03-18 17:03:46','2022-03-18 17:03:46');
/*!40000 ALTER TABLE `media__media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(10,0) NOT NULL,
  `quantity` int NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `image_id` int DEFAULT NULL,
  `gallery_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D34A04AD3DA5256D` (`image_id`),
  UNIQUE KEY `UNIQ_D34A04AD4E7AF8F` (`gallery_id`),
  KEY `IDX_D34A04AD12469DE2` (`category_id`),
  CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK_D34A04AD3DA5256D` FOREIGN KEY (`image_id`) REFERENCES `media__media` (`id`),
  CONSTRAINT `FK_D34A04AD4E7AF8F` FOREIGN KEY (`gallery_id`) REFERENCES `media__gallery` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,6,4,1,'Meizu 11','<p>dfhakdhfds</p>',1111,'2022-03-18 16:49:26'),(2,6,6,2,'Meizu22','<p>jdakhwj</p>',222,'2022-03-18 16:50:21'),(3,5,8,3,'Iphone22','<p>ewef</p>',33333,'2022-03-18 16:51:36'),(4,8,10,4,'Old red TV 1000','<p>wdwefw</p>',222,'2022-03-18 16:53:35'),(5,8,13,5,'Old red TV 1000','<p>wdwddwdw</p>',3333333,'2022-03-18 17:01:14'),(6,9,15,6,'New red tv 000','<p>ewgrtgwewrfelkaj afealkah fhwa fwal h;a</p>',333,'2022-03-18 17:02:08');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_to_orders`
--

DROP TABLE IF EXISTS `products_to_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_to_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `products_id` int DEFAULT NULL,
  `orders_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_918012556C8A81A9` (`products_id`),
  KEY `IDX_91801255CFFE9AD6` (`orders_id`),
  CONSTRAINT `FK_918012556C8A81A9` FOREIGN KEY (`products_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK_91801255CFFE9AD6` FOREIGN KEY (`orders_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_to_orders`
--

LOCK TABLES `products_to_orders` WRITE;
/*!40000 ALTER TABLE `products_to_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_to_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-18 16:16:08
